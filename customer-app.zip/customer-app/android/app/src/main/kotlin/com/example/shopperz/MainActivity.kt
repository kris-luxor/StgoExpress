package com.inilabs.shopking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
